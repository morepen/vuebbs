<template>
  <div id="footer" class="footer">
	<div class="fm clearfix">
		<div class="statement">
			<p class="link clearfix" v-show="false">
				<a href="">意见反馈</a>
				<a href="">关于我们</a>
				<a href="">免责声明</a>
				<a href="">官方QQ群</a>
			</p>
			<p class="info" v-show="false"><a href="http://www.dounide.com">逗你的</a> 网站所有图片均为用户免费分享产生，若发现您的权利被侵害，请联系493891498@qq.com ，我们会尽快处理</p>
			<p class="copy">Copyright © 2018 旅行日记</p>
		</div>
	</div>
</div>

</template>

<style scoped>
   @import '../assets/css/page/footer.css';
</style>
