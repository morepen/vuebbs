<template>
  <div class="to">
	 to
  </div>
</template>

<script>
</script>
<style>
 #header {
    width: 100%;
    height: 60px;
    background: white;
    border-bottom: 1px solid #e2e2e2;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
    position: fixed;
    top: 0;
    left: 0;
    z-index: 999;
}

#hint {
    position: fixed;
    top: -60px;
    z-index: 99999;
    width: 100%;
    font-size: 16px;
    height: 60px;
    line-height: 60px;
    text-align: center;
    color: white;
    background-color: #3498DB;
    opacity: 0.9;
}

#header .head-main {
    max-width: 1100px;
    padding: 0 10px;
    height: 60px;
    line-height: 50px;
    margin: 0 auto;
}

#header .head-main .logo {
    float: left;
    width: 120px;
    overflow: hidden;
}

#header .head-main .logo a {
    display: block;
    height: 0;
    margin-top: 15px;
    padding-top: 30px;
    overflow: hidden;
    background: url('/public/img/logo.png') no-repeat 0 0;
}

#header .head-main .band {
    float: left;
}

#header .head-main .band .port {
    float: right;
    display: none;
}

#header .head-main .band .port a {
    float: left;
    line-height: 45px;
    width: 45px;
    font-size: 24px;
    text-align: center;
    padding: 0 4px;
}

#header .head-main .band .port a:active {
    background-color: #eff3f5;
    color: #3498DB;
}

#header .head-main .menu {
    float: left;
}

#header .head-main .menu ul li {
    float: left;
    text-align: center;
}

#header .head-main .menu ul .on a {
    color: #3498DB;
}

#header .head-main .menu ul .user {
    display: none;
}

#header .head-main .menu ul li a {
    font-size: 16px;
    display: block;
    padding: 0 15px;
    border-top: 5px solid transparent;
}

#header .head-main .menu ul li a:hover {
    border-top: 5px solid #3498DB;
    box-shadow: 0 0 2px rgba(0, 0, 0, .1);
    color: #3498DB;
}

#header .head-main .login {
    float: right;
    max-width: 190px;
    height: 60px;
    box-sizing: border-box;
    font-size: 16px;
    border-top: 5px solid transparent;
    background-color: white;
    overflow: hidden;
}

#header .head-main .login:hover {
    border-top: 5px solid #3498DB;
    box-shadow: 0 0 2px rgba(0, 0, 0, .1);
    height: auto;
}
#header .head-main .login .login-btn:hover {
    background-color: #eff3f5;
}

#header .head-main .login .login-btn {
    display: block;
    padding: 0 15px;
    height: 55px;
    transition: all 0.3s;
    text-align: center;
    color: #3498DB;
    line-height: 50px;
}

#header .head-main .login .login-btn i {
    padding-right: 10px;
}

#header .head-main .login .login-btn img {
    vertical-align: middle;
    padding-right: 5px;
}

#header .head-main .login .quick {
    font-weight: bold;
}

#header .head-main .login .quick i {
    font-size: 25px;
    vertical-align: middle;
    position: relative;
    top: -2px;
}

#header .head-main .login .login-quick {
    color: #7a8e9d;
    height: 45px;
    line-height: 45px;
    font-size: 16px;
}

#header .head-main .login .login-quick:hover {
    color: #3498DB;
}

#header .head-main .login .login-quick i {
    font-size: 20px;
    vertical-align: middle;
}

#header .head-main .login .login-quick .set {
    position: relative;
    top: -2px;
}


#header .head-phone {
    display: none;
    width: 100%;
    height: 50px;
    line-height: 50px;
    background-color: white;
    position: relative;
    border-bottom: 1px solid #d1dbdc;
}

#header .head-phone i {
    position: absolute;
    font-size: 20px;
    width: 50px;
    text-align: center;
    top: 0;
    left: 0;
    cursor: pointer;
}

#header .head-phone h1 {
    text-align: center;
    font-size: 18px;
}

#header .head-phone a {
    position: absolute;
    font-size: 25px;
    width: 50px;
    padding: 10px 0;
    height: 30px;
    line-height: 30px;
    text-align: center;
    top: 0;
    right: 0;
    cursor: pointer;
}

#header .head-phone a img {
    width: 30px;
    height: 30px;
    border-radius: 50%;
}

#header .head-phone a:active {
    background-color: #efefef;
}

#header .head-phone i:active {
    background-color: #efefef;
}

/*
* 适应屏幕
* 770
*/

@media only screen and (max-width: 800px) {
    #header {
        height: auto;
        border: none;
        box-shadow: none;
    }

    #hint {
        height: 45px;
        line-height: 45px;
    }

    #header .head-main {
        line-height: normal;
        padding: 0;
        height: auto;
    }

    #header .head-main .login {
        display: none;
    }

    #header .head-main .band {
        height: 45px;
        float: none;
    }

    #header .head-main .logo {
        width: 198px;
    }

    #header .head-main .band .logo a {
        background: none;
        height: 45px;
        line-height: 45px;
        padding: 0;
        margin: 0;
        font-size: 18px;
        padding-left: 10px;
    }

    #header .head-main .band .port {
        display: block;
        height: 45px;
    }

    #header .head-main .menu {
        width: 100%;
        height: 40px;
        line-height: 40px;
        border-bottom: 1px solid #d1dbdc;
    }

    #header .head-main .menu .hid{
        display: none;
    }

    #header .head-main .menu ul .user{
        display: block;
    }

    #header .head-main .menu ul li {
        width: 25%;
    }

    #header .head-main .menu ul li a {
        border: none;
        border-bottom: 2px solid transparent;
        height: 38px;
    }

    #header .head-main .menu ul .on a {
        color: #3498DB;
        border: none;
    }

    #header .head-main .menu ul li a:hover {
        background-color: #e6e6e6;
        color: #3498DB;
        border: none;
        border-bottom: 2px solid #3498DB;
    }
}
.hc_login{
    margin:10px;
    width:40px;
    height:40px;
}
</style>

